import React from 'react';
import './style.css';

class Footer extends React.PureComponent {
  render() {
    return <footer>Footer</footer>;
  }
}

export default Footer;
