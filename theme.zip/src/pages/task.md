- create counter component
- use it three times in parent component
- in parent component you should display the total of counters
  note: use only useEffect to change the total value
