import { Container } from '../../global/components';

export default function HomePage({ title, ...rest }) {
  return (
    <div>
      <Container className='my-container'></Container>
    </div>
  );
}
